package com.example.sportforum;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class NFLAdapter  {
    private ForumDbHelper dbHelper;
    private Context context;
    private SQLiteDatabase database;
    public NFLAdapter(Context c){
        context = c;
    }
    public NFLAdapter open(){
        dbHelper = new ForumDbHelper(context);
        database = dbHelper.getWritableDatabase();
        return this;
    }
    public void close(){
        dbHelper.close();
    }
    public Cursor fetchPosts(){
        dbHelper = new ForumDbHelper(context);
        database = dbHelper.getWritableDatabase();
        String[] columns = new String[]{"ROWID as _id", ForumDbHelper.COLUMN_NFL_TITLE, ForumDbHelper.COLUMN_USERNAME, ForumDbHelper.COLUMN_NFL_POST};
        Cursor cursor = database.query(ForumDbHelper.TABLE_NFL_POST, columns, null, null, null, null, null);
        if(cursor != null){
            cursor.moveToFirst();
        }
        return cursor;
    }
    public Cursor fetchComments(String title){
        dbHelper = new ForumDbHelper(context);
        database = dbHelper.getWritableDatabase();

        String[] columns = new String[]{"ROWID as _id", ForumDbHelper.COLUMN_NFL_COMMENT, ForumDbHelper.COLUMN_USERNAME};
        String selection = ForumDbHelper.COLUMN_NFL_TITLE + "=?";
        String [] selectionArgs = {title};
        Cursor cursor = database.query(ForumDbHelper.TABLE_NFL_COMMENT, columns, selection, selectionArgs, null, null, null);
        if(cursor != null){
            cursor.moveToFirst();
        }
        return cursor;
    }
    public Cursor fetchUserPosts(){
        dbHelper = new ForumDbHelper(context);
        database = dbHelper.getWritableDatabase();
        SessionManager sessionManager = new SessionManager(context);

        String[] columns = new String[]{"ROWID as _id", ForumDbHelper.COLUMN_NFL_TITLE};
        String selection = ForumDbHelper.COLUMN_USERNAME + "=?";
        String [] selectionArgs = {sessionManager.getUsername()};
        Cursor cursor = database.query(ForumDbHelper.TABLE_NFL_POST, columns, selection, selectionArgs, null, null, null);
        if(cursor != null){
            cursor.moveToFirst();
        }
        return cursor;
    }
}

