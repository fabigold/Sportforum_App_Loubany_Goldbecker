package com.example.sportforum;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.sportforum.databinding.RegisterBinding;

public class Register extends AppCompatActivity {
    RegisterBinding binding;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = RegisterBinding.inflate(getLayoutInflater()); // saves the layout file
        setContentView(binding.getRoot()); // sets the view to the layout file
        ForumDbHelper databaseHelper = new ForumDbHelper(this);

        binding.btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = binding.eTUsername.getText().toString();
                String email = binding.eTEmail.getText().toString();
                String password = binding.eTPassword.getText().toString();
                if (username.equals("") || email.equals("") || password.equals(""))
                    Toast.makeText(Register.this, "All fields are mandatory", Toast.LENGTH_SHORT).show();
                else {
                    Boolean checkUser = databaseHelper.checkUsername(username);
                    Boolean checkEmail = databaseHelper.checkUserEmail(email);
                    if (checkUser == false) {
                        if (checkEmail == false) {
                            long insert = databaseHelper.addUser(username, email, password);
                            if (insert > 0) {
                                Toast.makeText(Register.this, "Registered Successfully!", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                                startActivity(intent);
                            } else {
                                Toast.makeText(Register.this, "Registration Failed!", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(Register.this, "Email already exists!", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(Register.this, "Username already exists!", Toast.LENGTH_SHORT).show();
                    }


                }

            }
        });




    }




}
