package com.example.sportforum;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.sportforum.databinding.NewpostfbBinding;

public class newPostFb extends AppCompatActivity {

    NewpostfbBinding binding;
    SessionManager sessionManager;

    ForumDbHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = NewpostfbBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        databaseHelper = new ForumDbHelper(this);


        // Initialize the SessionManager instance
        sessionManager = new SessionManager(getApplicationContext());

        binding.btnNewPost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = binding.eTTitle.getText().toString();
                String content = binding.eTContent.getText().toString();

                // Get the username from the session
                String username = sessionManager.getUsername();

                if (title.equals("") || content.equals("")) {
                    Toast.makeText(newPostFb.this, "All fields are mandatory", Toast.LENGTH_SHORT).show();
                } else {
                    Boolean checkPost = databaseHelper.checkFBPost(title);
                    if (checkPost == true) {
                        long insert = databaseHelper.addFBPost(title, content, username);
                        if (insert > 0) {
                            Toast.makeText(newPostFb.this, "Post succesful!", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(), fb.class);
                            startActivity(intent);
                        } else {
                            Toast.makeText(newPostFb.this, "Invalid Post", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(newPostFb.this, "Title exists", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
