package com.example.sportforum;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class Home extends AppCompatActivity {

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.homescreen);


            Button btnProfile = findViewById(R.id.btnProfil);
            btnProfile.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent gotoProfile = new Intent(Home.this, Profile.class);
                    startActivity(gotoProfile);
                }
            });

            Button btnNFL = findViewById(R.id.btnNFL);
            btnNFL.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent gotoNFL = new Intent(Home.this, NFL.class);
                    startActivity(gotoNFL);
                }
            });

            Button btnFootball = findViewById(R.id.btnFootball);
            btnFootball.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent gotoFootball = new Intent(Home.this, fb.class);
                    startActivity(gotoFootball);
                }
            });
        }

}
