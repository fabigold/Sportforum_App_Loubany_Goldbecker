package com.example.sportforum;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

public class ForumDataSource {

    private static final String LOG_TAG = ForumDataSource.class.getSimpleName();

    private SQLiteDatabase database;
    private ForumDbHelper dbHelper;

    public ForumDataSource(Context context) { // Context = Umgebung, in der die App läuft (z.B. Activity)
        Log.d(LOG_TAG, "Unsere DataSource erzeugt jetzt den dbHelper.");
        dbHelper = new ForumDbHelper(context); // Erzeugt die Datenbank mit dem Namen Sportforum.db
    }
}
