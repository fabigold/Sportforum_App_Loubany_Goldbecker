package com.example.sportforum;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

public class NFL extends AppCompatActivity {

    private ForumDbHelper dbHelper;
    private NFLAdapter manager;
    private ListView listView;
    private Button newPost;
    private SimpleCursorAdapter adapter;
    final String [] from = new String[]{ForumDbHelper.COLUMN_NFL_TITLE};
    final int [] to = new int[]{R.id.nfl_post_title};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nfl);

        dbHelper = new ForumDbHelper(this);
        manager = new NFLAdapter(this);
        manager.open();
        Cursor cursor = manager.fetchPosts();

        listView = (ListView) findViewById(R.id.list_view);

        adapter = new SimpleCursorAdapter(this, R.layout.nfl_posts, cursor, from, to, 0);
        adapter.notifyDataSetChanged();

        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                TextView titleTextView = (TextView) view.findViewById(R.id.nfl_post_title);

                String title = titleTextView.getText().toString();

                Intent gotoPost = new Intent(getApplicationContext(), nflPosts.class);
                gotoPost.putExtra("title", title);

                startActivity(gotoPost);
            }
        });
        newPost = (Button) findViewById(R.id.new_post_button);
        newPost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gotoNewPost = new Intent(getApplicationContext(), newPostNFL.class);
                startActivity(gotoNewPost);
            }
        });

    }
}