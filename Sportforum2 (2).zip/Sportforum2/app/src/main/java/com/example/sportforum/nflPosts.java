package com.example.sportforum;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.sportforum.databinding.NflPostBinding;

public class nflPosts extends AppCompatActivity {

    private TextView titleTextView;
    private TextView contentTextView;
    private TextView usernameTextView;

    private NFLAdapter manager;
    NflPostBinding binding;
    ListView listView;
    ForumDbHelper dbHelper;
    SessionManager sessionManager;
    private SimpleCursorAdapter adapter;
    final String [] from = new String[]{ForumDbHelper.COLUMN_NFL_COMMENT, ForumDbHelper.COLUMN_USERNAME};
    final int [] to = new int[]{R.id.comment, R.id.username};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = NflPostBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        dbHelper = new ForumDbHelper(this);
        manager = new NFLAdapter(this);
        manager.open();


        listView = (ListView) findViewById(R.id.comments_listview);

        // Initialize the SessionManager instance
        sessionManager = new SessionManager(getApplicationContext());

        titleTextView = findViewById(R.id.nfl_post_title);
        contentTextView = findViewById(R.id.nfl_post_content);
        usernameTextView = findViewById(R.id.nfl_post_username);


        Intent intent = getIntent();
        String title = intent.getStringExtra("title");

        // Query the database for the post with the selected title
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] projection = {
                ForumDbHelper.COLUMN_NFL_POST,
                ForumDbHelper.COLUMN_USERNAME
        };
        String selection = ForumDbHelper.COLUMN_NFL_TITLE + "=?";
        String[] selectionArgs = {title};
        Cursor c = db.query(
                ForumDbHelper.TABLE_NFL_POST,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        if (c != null && c.moveToFirst()) {
            // Set the text views to display the post details
            @SuppressLint("Range") String content = c.getString(c.getColumnIndex(ForumDbHelper.COLUMN_NFL_POST));
            @SuppressLint("Range") String username = c.getString(c.getColumnIndex(ForumDbHelper.COLUMN_USERNAME));
            contentTextView.setText(content);
            usernameTextView.setText(username);
            titleTextView.setText(title);
            c.close();
        }

        binding.btnComment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String comment = binding.eTComment.getText().toString();
                String title = binding.nflPostTitle.getText().toString();

                // Get the username from the session
                String username = sessionManager.getUsername();

                if (comment.equals("")) {
                    Toast.makeText(nflPosts.this, "Please write a comment", Toast.LENGTH_SHORT).show();
                } else {
                    long insert = dbHelper.addNFLComment(comment, username, title);
                    if (insert > 0) {
                        Toast.makeText(nflPosts.this, "Comment successful!", Toast.LENGTH_SHORT).show();
                        binding.eTComment.getText().clear();
                        Cursor newCursor = manager.fetchComments(title);
                        adapter.changeCursor(newCursor);
                        adapter.notifyDataSetChanged();

                    }
                }
            }
        });
        Cursor cursor = manager.fetchComments(title);
        adapter = new SimpleCursorAdapter(this, R.layout.comment_list_item, cursor, from, to, 0);
        adapter.notifyDataSetChanged();

        listView.setAdapter(adapter);
    }
}



