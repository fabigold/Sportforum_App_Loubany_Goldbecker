package com.example.sportforum;


import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import com.example.sportforum.databinding.ProfileBinding;

public class Profile extends AppCompatActivity {

    ProfileBinding binding;
    private NFLAdapter manager;
    private fbAdapter manager2;
    private ListView listView;
    private ListView listView2;
    private SimpleCursorAdapter adapter;
    final String [] from = new String[]{ForumDbHelper.COLUMN_NFL_TITLE};
    final int [] to = new int[]{R.id.nfl_post_title};
    final String [] from2 = new String[]{ForumDbHelper.COLUMN_FB_TITLE};
    final int [] to2 = new int[]{R.id.fb_post_title};






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ProfileBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        manager = new NFLAdapter(this);
        manager.open();
        Cursor cursor = manager.fetchUserPosts();

        listView = (ListView) findViewById(R.id.listViewNFL);
        listView2 = (ListView) findViewById(R.id.listViewFb);



        adapter = new SimpleCursorAdapter(this, R.layout.nfl_posts, cursor, from, to, 0);
        adapter.notifyDataSetChanged();

        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                TextView titleTextView = (TextView) view.findViewById(R.id.nfl_post_title);

                String title = titleTextView.getText().toString();

                Intent gotoPost = new Intent(getApplicationContext(), nflPosts.class);
                gotoPost.putExtra("title", title);

                startActivity(gotoPost);
            }
        });

        manager2 = new fbAdapter(this);
        manager2.open();
        Cursor c = manager2.fetchUserFBPosts();
        adapter = new SimpleCursorAdapter(this, R.layout.fb_posts, c, from2, to2, 0);
        adapter.notifyDataSetChanged();
        listView2.setAdapter(adapter);

        listView2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                TextView titleTextView = (TextView) view.findViewById(R.id.fb_post_title);

                String title = titleTextView.getText().toString();

                Intent gotoFBPost = new Intent(getApplicationContext(), fbPosts.class);
                gotoFBPost.putExtra("title", title);

                startActivity(gotoFBPost);
            }
        });

        SessionManager sessionManager = new SessionManager(getApplicationContext());

        binding.tVUsername.setText(sessionManager.getUsername());


        binding.btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sessionManager.logout();
            }
        });




    }
    }