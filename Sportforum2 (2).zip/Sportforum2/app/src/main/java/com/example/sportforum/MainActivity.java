package com.example.sportforum;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;


import com.example.sportforum.databinding.LoginBinding;
public class MainActivity extends AppCompatActivity {

    LoginBinding binding;
    ForumDbHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = LoginBinding.inflate(getLayoutInflater()); // saves the layout file activity_login.xml to binding
        setContentView(binding.getRoot()); // sets the view to the layout file activity_login.xml

        databaseHelper = new ForumDbHelper(this);

        binding.btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = binding.eTUsername.getText().toString();
                String password = binding.eTPassword.getText().toString();
                if(username.equals("")||password.equals(""))
                    Toast.makeText(MainActivity.this, "All fields are mandatory", Toast.LENGTH_SHORT).show();
                else{
                    Boolean checkCredentials = databaseHelper.checkUserLogin(username, password);
                    if(checkCredentials == true){
                        SessionManager sessionManager = new SessionManager(MainActivity.this);
                        sessionManager.createSession(username);
                        Toast.makeText(MainActivity.this, "Login Successfully!", Toast.LENGTH_SHORT).show();
                        Intent intent  = new Intent(getApplicationContext(), Home.class);
                        startActivity(intent);
                    }else{
                        Toast.makeText(MainActivity.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        binding.btnNewAcc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gotoRegister = new Intent(MainActivity.this, Register.class);
                startActivity(gotoRegister);
            }
        });

    }
}