package com.example.sportforum;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.sportforum.databinding.NewpostnflBinding;

public class newPostNFL extends AppCompatActivity {

    NewpostnflBinding binding;
    SessionManager sessionManager;

    ForumDbHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = NewpostnflBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        databaseHelper = new ForumDbHelper(this);


        // Initialize the SessionManager instance
        sessionManager = new SessionManager(getApplicationContext());

        binding.btnNewPost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = binding.eTTitle.getText().toString();
                String content = binding.eTContent.getText().toString();

                // Get the username from the session
                String username = sessionManager.getUsername();

                if (title.equals("") || content.equals("")) {
                    Toast.makeText(newPostNFL.this, "All fields are mandatory", Toast.LENGTH_SHORT).show();
                } else {
                    Boolean checkPost = databaseHelper.checkNFLPost(title);
                    if (checkPost == true) {
                        long insert = databaseHelper.addNFLPost(title, content, username);
                        if (insert > 0) {
                            Toast.makeText(newPostNFL.this, "Post succesful!", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(), NFL.class);
                            startActivity(intent);
                        } else {
                            Toast.makeText(newPostNFL.this, "Invalid Post", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(newPostNFL.this, "Title exists", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}