package com.example.sportforum;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


public class ForumDbHelper extends SQLiteOpenHelper {



    private static final int DATABASE_VERSION = 1; // wird bei jeder Änderung der DB erhöht
    private static final String DATABASE_NAME = "Sportforum.db";
    public static final String TABLE_USER = "user"; // Name der Tabelle
    private static final String COLUMN_USER_ID = "user_id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_EMAIL = "email";
    private static final String COLUMN_PASSWORD = "password";

    public static final String TABLE_FB_POST = "fb_post";
    public static final String COLUMN_FB_POST_ID = "fb_post_id";
    public static final String COLUMN_FB_TITLE = "fb_title";
    public static final String COLUMN_FB_POST = "fb_content";

    public static final String TABLE_FB_COMMENT = "fb_comment";
    public static final String COLUMN_FB_COMMENT_ID = "fb_comment_id";
    public static final String COLUMN_FB_COMMENT = "fb_comment_content";

    public static final String TABLE_NFL_POST = "nfl_post";
    public static final String COLUMN_NFL_POST_ID = "nfl_post_id";
    public static final String COLUMN_NFL_TITLE = "nfl_title";
    public static final String COLUMN_NFL_POST = "nfl_content";

    public static final String TABLE_NFL_COMMENT = "nfl_comment";
    public static final String COLUMN_NFL_COMMENT_ID = "nfl_comment_id";
    public static final String COLUMN_NFL_COMMENT = "nfl_comment_content";


    private String CREATE_USER_TABLE = "CREATE TABLE " + TABLE_USER + "("
            + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_USERNAME + " TEXT,"
            + COLUMN_EMAIL + " TEXT,"
            + COLUMN_PASSWORD + " TEXT" +
            ")";

    private String CREATE_FB_POST_TABLE = "CREATE TABLE " + TABLE_FB_POST + "("
            + COLUMN_FB_POST_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_FB_TITLE + " TEXT,"
            + COLUMN_FB_POST + " TEXT,"
            + COLUMN_USERNAME + " TEXT" +
            ")";

    private String CREATE_FB_COMMENT_TABLE = "CREATE TABLE " + TABLE_FB_COMMENT + "("
            + COLUMN_FB_COMMENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_FB_COMMENT + " TEXT,"
            + COLUMN_USERNAME + " TEXT,"
            + COLUMN_FB_TITLE + " TEXT" +
            ")";

    public String CREATE_NFL_POST_TABLE = "CREATE TABLE " + TABLE_NFL_POST + "("
            + COLUMN_NFL_POST_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_NFL_TITLE + " TEXT,"
            + COLUMN_NFL_POST + " TEXT,"
            + COLUMN_USERNAME + " TEXT" +
            ")";

    public String CREATE_NFL_COMMENT_TABLE = "CREATE TABLE " + TABLE_NFL_COMMENT + "("
            + COLUMN_NFL_COMMENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_NFL_COMMENT + " TEXT,"
            + COLUMN_USERNAME + " TEXT, "
            + COLUMN_NFL_TITLE + " TEXT" +
            ")";

    private String DROP_USER_TABLE = "DROP TABLE IF EXISTS " + TABLE_USER;
    private String DROP_FB_POST_TABLE = "DROP TABLE IF EXISTS " + TABLE_FB_POST;
    private String DROP_FB_COMMENT_TABLE = "DROP TABLE IF EXISTS " + TABLE_FB_COMMENT;
    private String DROP_NFL_POST_TABLE = "DROP TABLE IF EXISTS " + TABLE_NFL_POST;
    private String DROP_NFL_COMMENT_TABLE = "DROP TABLE IF EXISTS " + TABLE_NFL_COMMENT;
    private static final String LOG_TAG = ForumDbHelper.class.getSimpleName();


    public ForumDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION); //Deklaration DB, context = path to database,
        Log.d(LOG_TAG, "DbHelper hat die Datenbank: " + getDatabaseName() + " erzeugt."); // Druck in der Logcat Konsolenausgabe
    }

    public void onCreate(SQLiteDatabase db) {
        try {
            db.execSQL(CREATE_USER_TABLE); // Erzeugt die Tabelle
            db.execSQL(CREATE_FB_POST_TABLE);
            db.execSQL(CREATE_FB_COMMENT_TABLE);
            db.execSQL(CREATE_NFL_POST_TABLE);
            db.execSQL(CREATE_NFL_COMMENT_TABLE);
        } catch (Exception e) {
            Log.e(LOG_TAG, "Fehler beim Anlegen der Tabelle: " + e.getMessage());
        }

    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { // Erhöhung der Versionsnummer,
        db.execSQL(DROP_USER_TABLE); // Löscht die Tabelle, wenn bereits bestehend
        db.execSQL(DROP_FB_POST_TABLE);
        db.execSQL(DROP_FB_COMMENT_TABLE);
        db.execSQL(DROP_NFL_POST_TABLE);
        db.execSQL(DROP_NFL_COMMENT_TABLE);
        onCreate(db);
    }

    public long addUser(String username, String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_EMAIL, email);
        values.put(COLUMN_PASSWORD, password);
        long result = db.insert(TABLE_USER, null, values);
        db.close();
        return result;
    }


    public Boolean checkUsername(String username) { // Überprüft ob der Username bereits in der DB vorhanden ist, (Registrierung)
        String[] columns = {
                COLUMN_USER_ID
        };
        SQLiteDatabase db = this.getReadableDatabase();
        String selection = COLUMN_USERNAME + " = ?";
        String[] selectionArgs = {username};
        Cursor cur = db.query(TABLE_USER,
                columns,
                selection,
                selectionArgs,
                null,
                null,
                null);
        int cursorCount = cur.getCount();
        cur.close();
        db.close();
        if (cursorCount > 0) { // Wenn der Username bereits vorhanden ist, wird true zurückgegeben
            return true;
        } else {
            return false;
        }

    }
    public Boolean checkUserEmail(String email) { // Überprüft ob die Email bereits in der DB vorhanden ist, (Registrierung)
        String[] columns = {
                COLUMN_USER_ID
        };
        SQLiteDatabase db = this.getReadableDatabase();
        String selection = COLUMN_EMAIL + " = ?";
        String[] selectionArgs = {email};
        Cursor cur = db.query(TABLE_USER,
                columns,
                selection,
                selectionArgs,
                null,
                null,
                null);
        int cursorCount = cur.getCount();
        cur.close();
        db.close();
        if (cursorCount > 0) {
            return true;
        } else {
            return false;
        }
    }

    boolean checkUserLogin(String username, String password) { // Überprüft ob der Username und das Passwort in der DB vorhanden sind (Login)
        String[] columns = {
                COLUMN_USER_ID
        };
        SQLiteDatabase db = this.getReadableDatabase();
        String selection = COLUMN_USERNAME + " = ?" + " AND " + COLUMN_PASSWORD + " = ?";
        String[] selectionArgs = {username, password};
        Cursor cur = db.query(TABLE_USER,
                columns,
                selection,
                selectionArgs,
                null,
                null,
                null);

        int cursorCount = cur.getCount();
        cur.close();
        db.close();
        return cursorCount > 0;
    }


    public Boolean checkNFLPost(String title) {
        String[] columns = {
                COLUMN_NFL_POST_ID
        };
        SQLiteDatabase db = this.getReadableDatabase();
        String selection = COLUMN_NFL_TITLE + " = ?";
        String[] selectionArgs = {title};
        Cursor cur = db.query(TABLE_NFL_POST,
                columns,
                selection,
                selectionArgs,
                null,
                null,
                null);
        int cursorCount = cur.getCount();
        cur.close();
        db.close();
        if (cursorCount > 0) {
            return false;
        } else {
            return true;
        }
    }

    public long addNFLPost(String title, String content, String username) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NFL_TITLE, title);
        values.put(COLUMN_NFL_POST, content);
        values.put(COLUMN_USERNAME, username);
        long result = db.insert(TABLE_NFL_POST, null, values);
        db.close();
        return result;
    }

    public long addNFLComment(String comment, String username, String title) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NFL_COMMENT, comment);
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_NFL_TITLE, title);
        long result = db.insert(TABLE_NFL_COMMENT, null, values);
        db.close();
        return result;
    }
    public Boolean checkFBPost(String title) {
        String[] columns = {
                COLUMN_FB_POST_ID
        };
        SQLiteDatabase db = this.getReadableDatabase();
        String selection = COLUMN_FB_TITLE + " = ?";
        String[] selectionArgs = {title};
        Cursor cur = db.query(TABLE_FB_POST,
                columns,
                selection,
                selectionArgs,
                null,
                null,
                null);
        int cursorCount = cur.getCount();
        cur.close();
        db.close();
        if (cursorCount > 0) {
            return false;
        } else {
            return true;
        }
    }

    public long addFBPost(String title, String content, String username) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_FB_TITLE, title);
        values.put(COLUMN_FB_POST, content);
        values.put(COLUMN_USERNAME, username);
        long result = db.insert(TABLE_FB_POST, null, values);
        db.close();
        return result;
    }

    public long addFBComment(String comment, String username, String title) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_FB_COMMENT, comment);
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_FB_TITLE, title);
        long result = db.insert(TABLE_FB_COMMENT, null, values);
        db.close();
        return result;
    }

}



